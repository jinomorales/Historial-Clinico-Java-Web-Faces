package modelo;

public class Usuarios {

    //campos usuario
    private int id;
    private String lastname1;
    private String lastname2;
    private String name1;
    private String name2;
    private String document;

    //tabla1
    private String n1, c1, c2, c3, c4, c5, c6, c7;

    //tabla2
    private String n2, r1, r2;

    //tabla3
    private String n3, region1, region2, region3, punto1, punto2, punto3;

    //tabla4
    private String t1, t2, t3, t4, t5, t6, t7, t8, t9, t10, t11, t12, t13, t14, t15, t16, t17, t18, t19, t20, t21, t22, t23, t24, t25, t26, t27, t28, t29, t30;

    //tabla5
    private String i1, i2, i3, tf1, tf2, tf3, tf4, tf5, tf6, tf7, tf8, tf9, tf10, tf11, tf12, tf13, tf14, tf15, tf16, tf17, tf18, tf19, tf20, tf21, tf22, tf23, tf24;
    
    public Usuarios(int id, String lastname1, String lastname2, String name1, String name2, String document,
            String n1, String c1, String c2, String c3, String c4, String c5, String c6, String c7,
            String n2, String r1, String r2,
            String n3, String region1, String region2, String region3, String punto1, String punto2, String punto3,
            String t1, String t2, String t3, String t4, String t5, String t6, String t7, String t8, String t9, String t10, String t11, String t12, String t13, String t14, String t15, String t16, String t17, String t18, String t19, String t20, String t21, String t22, String t23, String t24, String t25, String t26, String t27, String t28, String t29, String t30,
            String i1,String i2,String i3,String tf1,String tf2,String tf3,String tf4,String tf5,String tf6,String tf7,String tf8,String tf9,String tf10,String tf11,String tf12,String tf13,String tf14,String tf15,String tf16,String tf17,String tf18,String tf19,String tf20,String tf21,String tf22,String tf23,String tf24) {

        this.id = id;
        this.lastname1 = lastname1;
        this.lastname2 = lastname2;
        this.name1 = name1;
        this.name2 = name2;
        this.document = document;

        this.n1 = n1;
        this.c1 = c1;
        this.c2 = c2;
        this.c3 = c3;
        this.c4 = c4;
        this.c5 = c5;
        this.c6 = c6;
        this.c7 = c7;

        this.n2 = n2;
        this.r1 = r1;
        this.r2 = r2;

        this.n3 = n3;
        this.region1 = region1;
        this.region2 = region2;
        this.region3 = region3;
        this.punto1 = punto1;
        this.punto2 = punto2;
        this.punto3 = punto3;

        this.t1 = t1;
        this.t2 = t2;
        this.t3 = t3;
        this.t4 = t4;
        this.t5 = t5;
        this.t6 = t6;
        this.t7 = t7;
        this.t8 = t8;
        this.t9 = t9;
        this.t10 = t10;
        this.t11 = t11;
        this.t12 = t12;
        this.t13 = t13;
        this.t14 = t14;
        this.t15 = t15;
        this.t16 = t16;
        this.t17 = t17;
        this.t18 = t18;
        this.t19 = t19;
        this.t20 = t20;
        this.t21 = t21;
        this.t22 = t22;
        this.t23 = t23;
        this.t24 = t24;
        this.t25 = t25;
        this.t26 = t26;
        this.t27 = t27;
        this.t28 = t28;
        this.t29 = t29;
        this.t30 = t30;

        this.i1 = i1;
        this.i2 = i1;
        this.i3 = i1;
        this.tf1 = tf1;
        this.tf2 = tf2;
        this.tf3 = tf3;
        this.tf4 = tf4;
        this.tf5 = tf5;
        this.tf6 = tf6;
        this.tf7 = tf7;
        this.tf8 = tf8;
        this.tf9 = tf9;
        this.tf10 = tf10;
        this.tf11 = tf11;
        this.tf12 = tf12;
        this.tf13 = tf13;
        this.tf14 = tf14;
        this.tf15 = tf15;
        this.tf16 = tf16;
        this.tf17 = tf17;
        this.tf18 = tf18;
        this.tf19 = tf19;
        this.tf20 = tf20;
        this.tf21 = tf21;
        this.tf22 = tf22;
        this.tf23 = tf23;
        this.tf24 = tf24;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getLastname1() {
        return lastname1;
    }

    public void setLastname1(String lastname1) {
        this.lastname1 = lastname1;
    }

    public String getLastname2() {
        return lastname2;
    }

    public void setLastname2(String lastname2) {
        this.lastname2 = lastname2;
    }

    public String getName1() {
        return name1;
    }

    public void setName1(String name1) {
        this.name1 = name1;
    }

    public String getName2() {
        return name2;
    }

    public void setName2(String name2) {
        this.name2 = name2;
    }

    public String getDocument() {
        return document;
    }

    public void setDocument(String document) {
        this.document = document;
    }

    public String getN1() {
        return n1;
    }

    public void setN1(String n1) {
        this.n1 = n1;
    }

    public String getC1() {
        return c1;
    }

    public void setC1(String c1) {
        this.c1 = c1;
    }

    public String getC2() {
        return c2;
    }

    public void setC2(String c2) {
        this.c2 = c2;
    }

    public String getC3() {
        return c3;
    }

    public void setC3(String c3) {
        this.c3 = c3;
    }

    public String getC4() {
        return c4;
    }

    public void setC4(String c4) {
        this.c4 = c4;
    }

    public String getC5() {
        return c5;
    }

    public void setC5(String c5) {
        this.c5 = c5;
    }

    public String getC6() {
        return c6;
    }

    public void setC6(String c6) {
        this.c6 = c6;
    }

    public String getC7() {
        return c7;
    }

    public void setC7(String c7) {
        this.c7 = c7;
    }

    public String getN2() {
        return n2;
    }

    public void setN2(String n2) {
        this.n2 = n2;
    }

    public String getR1() {
        return r1;
    }

    public void setR1(String r1) {
        this.r1 = r1;
    }

    public String getR2() {
        return r2;
    }

    public void setR2(String r2) {
        this.r2 = r2;
    }

    public String getN3() {
        return n3;
    }

    public void setN3(String n3) {
        this.n3 = n3;
    }

    public String getRegion1() {
        return region1;
    }

    public void setRegion1(String region1) {
        this.region1 = region1;
    }

    public String getRegion2() {
        return region2;
    }

    public void setRegion2(String region2) {
        this.region2 = region2;
    }

    public String getRegion3() {
        return region3;
    }

    public void setRegion3(String region3) {
        this.region3 = region3;
    }

    public String getPunto1() {
        return punto1;
    }

    public void setPunto1(String punto1) {
        this.punto1 = punto1;
    }

    public String getPunto2() {
        return punto2;
    }

    public void setPunto2(String punto2) {
        this.punto2 = punto2;
    }

    public String getPunto3() {
        return punto3;
    }

    public void setPunto3(String punto3) {
        this.punto3 = punto3;
    }

    public String getT1() {
        return t1;
    }

    public void setT1(String t1) {
        this.t1 = t1;
    }

    public String getT2() {
        return t2;
    }

    public void setT2(String t2) {
        this.t2 = t2;
    }

    public String getT3() {
        return t3;
    }

    public void setT3(String t3) {
        this.t3 = t3;
    }

    public String getT4() {
        return t4;
    }

    public void setT4(String t4) {
        this.t4 = t4;
    }

    public String getT5() {
        return t5;
    }

    public void setT5(String t5) {
        this.t5 = t5;
    }

    public String getT6() {
        return t6;
    }

    public void setT6(String t6) {
        this.t6 = t6;
    }

    public String getT7() {
        return t7;
    }

    public void setT7(String t7) {
        this.t7 = t7;
    }

    public String getT8() {
        return t8;
    }

    public void setT8(String t8) {
        this.t8 = t8;
    }

    public String getT9() {
        return t9;
    }

    public void setT9(String t9) {
        this.t9 = t9;
    }

    public String getT10() {
        return t10;
    }

    public void setT10(String t10) {
        this.t10 = t10;
    }

    public String getT11() {
        return t11;
    }

    public void setT11(String t11) {
        this.t11 = t11;
    }

    public String getT12() {
        return t12;
    }

    public void setT12(String t12) {
        this.t12 = t12;
    }

    public String getT13() {
        return t13;
    }

    public void setT13(String t13) {
        this.t13 = t13;
    }

    public String getT14() {
        return t14;
    }

    public void setT14(String t14) {
        this.t14 = t14;
    }

    public String getT15() {
        return t15;
    }

    public void setT15(String t15) {
        this.t15 = t15;
    }

    public String getT16() {
        return t16;
    }

    public void setT16(String t16) {
        this.t16 = t16;
    }

    public String getT17() {
        return t17;
    }

    public void setT17(String t17) {
        this.t17 = t17;
    }

    public String getT18() {
        return t18;
    }

    public void setT18(String t18) {
        this.t18 = t18;
    }

    public String getT19() {
        return t19;
    }

    public void setT19(String t19) {
        this.t19 = t19;
    }

    public String getT20() {
        return t20;
    }

    public void setT20(String t20) {
        this.t20 = t20;
    }

    public String getT21() {
        return t21;
    }

    public void setT21(String t21) {
        this.t21 = t21;
    }

    public String getT22() {
        return t22;
    }

    public void setT22(String t22) {
        this.t22 = t22;
    }

    public String getT23() {
        return t23;
    }

    public void setT23(String t23) {
        this.t23 = t23;
    }

    public String getT24() {
        return t24;
    }

    public void setT24(String t24) {
        this.t24 = t24;
    }

    public String getT25() {
        return t25;
    }

    public void setT25(String t25) {
        this.t25 = t25;
    }

    public String getT26() {
        return t26;
    }

    public void setT26(String t26) {
        this.t26 = t26;
    }

    public String getT27() {
        return t27;
    }

    public void setT27(String t27) {
        this.t27 = t27;
    }

    public String getT28() {
        return t28;
    }

    public void setT28(String t28) {
        this.t28 = t28;
    }

    public String getT29() {
        return t29;
    }

    public void setT29(String t29) {
        this.t29 = t29;
    }

    public String getT30() {
        return t30;
    }

    public void setT30(String t30) {
        this.t30 = t30;
    }

    public String getI1() {
        return i1;
    }

    public void setI1(String i1) {
        this.i1 = i1;
    }

    public String getI2() {
        return i2;
    }

    public void setI2(String i2) {
        this.i2 = i2;
    }

    public String getI3() {
        return i3;
    }

    public void setI3(String i3) {
        this.i3 = i3;
    }

    public String getTf1() {
        return tf1;
    }

    public void setTf1(String tf1) {
        this.tf1 = tf1;
    }

    public String getTf2() {
        return tf2;
    }

    public void setTf2(String tf2) {
        this.tf2 = tf2;
    }

    public String getTf3() {
        return tf3;
    }

    public void setTf3(String tf3) {
        this.tf3 = tf3;
    }

    public String getTf4() {
        return tf4;
    }

    public void setTf4(String tf4) {
        this.tf4 = tf4;
    }

    public String getTf5() {
        return tf5;
    }

    public void setTf5(String tf5) {
        this.tf5 = tf5;
    }

    public String getTf6() {
        return tf6;
    }

    public void setTf6(String tf6) {
        this.tf6 = tf6;
    }

    public String getTf7() {
        return tf7;
    }

    public void setTf7(String tf7) {
        this.tf7 = tf7;
    }

    public String getTf8() {
        return tf8;
    }

    public void setTf8(String tf8) {
        this.tf8 = tf8;
    }

    public String getTf9() {
        return tf9;
    }

    public void setTf9(String tf9) {
        this.tf9 = tf9;
    }

    public String getTf10() {
        return tf10;
    }

    public void setTf10(String tf10) {
        this.tf10 = tf10;
    }

    public String getTf11() {
        return tf11;
    }

    public void setTf11(String tf11) {
        this.tf11 = tf11;
    }

    public String getTf12() {
        return tf12;
    }

    public void setTf12(String tf12) {
        this.tf12 = tf12;
    }

    public String getTf13() {
        return tf13;
    }

    public void setTf13(String tf13) {
        this.tf13 = tf13;
    }

    public String getTf14() {
        return tf14;
    }

    public void setTf14(String tf14) {
        this.tf14 = tf14;
    }

    public String getTf15() {
        return tf15;
    }

    public void setTf15(String tf15) {
        this.tf15 = tf15;
    }

    public String getTf16() {
        return tf16;
    }

    public void setTf16(String tf16) {
        this.tf16 = tf16;
    }

    public String getTf17() {
        return tf17;
    }

    public void setTf17(String tf17) {
        this.tf17 = tf17;
    }

    public String getTf18() {
        return tf18;
    }

    public void setTf18(String tf18) {
        this.tf18 = tf18;
    }

    public String getTf19() {
        return tf19;
    }

    public void setTf19(String tf19) {
        this.tf19 = tf19;
    }

    public String getTf20() {
        return tf20;
    }

    public void setTf20(String tf20) {
        this.tf20 = tf20;
    }

    public String getTf21() {
        return tf21;
    }

    public void setTf21(String tf21) {
        this.tf21 = tf21;
    }

    public String getTf22() {
        return tf22;
    }

    public void setTf22(String tf22) {
        this.tf22 = tf22;
    }

    public String getTf23() {
        return tf23;
    }

    public void setTf23(String tf23) {
        this.tf23 = tf23;
    }

    public String getTf24() {
        return tf24;
    }

    public void setTf24(String tf24) {
        this.tf24 = tf24;
    }
    
    

}
